<?php

/* 
ESTE ARCHIVO ES SOLO PARA PRUEBAS PUNTUALES
 */
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<script src="https://connect.facebook.net/es_LA/sdk.js?hash=8594d90fcb940433c128fc5daab911b9" async="" crossorigin="anonymous"></script>
<script async="" src="https://connect.facebook.net/es_LA/sdk.js"></script>
<script id="facebook-jssdk" src="//connect.facebook.net/es_LA/sdk.js"></script>
<script id="accountkit-jssdk" src="https://sdk.accountkit.com/es_LA/sdk.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link type="text/css" rel="stylesheet" href="css/flexbox-galery.css"></script>
 <script type="text/javascript" src="js/flexbox-galery.js"></script>
<title>Beta Shop</title>
</head>
<body>
<p>Iniciar sesi&oacute;n con Facebook:</p>


<div id="container" class="container">
        <figure>
            <img src="iconos/facebookkk.png">
        </figure>
        <figure>
            <img src="iconos/google.jpg">
        </figure>
        <figure>
            <img src="iconos/google.png">
        </figure>
        <figure>
            <img src="iconos/icono.jpg">
        </figure><figure>
            <img src="iconos/icono_facebook.png">
        </figure>
        <figure>
            <img src="iconos/icono_facebook.png">
        </figure><figure>
            <img src="iconos/imagen.png">
        </figure>
        
       
      </div>

<script>
$('#container').flexgal();
</script>
</html>


