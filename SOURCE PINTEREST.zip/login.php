
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
$conn = oci_connect('DB_PINTEREST', 'oracle', 'localhost:1521/XE');
if (!$conn) {
   $m = oci_error();
   echo $m['message'], "\n";
   exit;
}
else {
   print "Connected to Oracle!<br>";
}
// Analizar la sentencia. Observe que no hay punto y coma final en la sentencia SQL
$stid = oci_parse($conn, 'SELECT USUARIO FROM USUARIOS WHERE CONTRASENA= :did ORDER BY USUARIO');
$did="HHHH";
oci_bind_by_name($stid, ':did', $did);
oci_execute($stid);


while(($usuario=oci_fetch_array($stid, OCI_ASSOC)) != false){
    echo "<br>USUARIO: ".$usuario['USUARIO'];
}
oci_free_statement($stid);
oci_close($conn);
?>
