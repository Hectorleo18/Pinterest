<?php

/* 
ESTE ARCHIVO ES SOLO PARA PRUEBAS PUNTUALES
 */
?>
<!DOCTYPE HTML>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registro</title>
</head>
<body>
    <form action="registro.php" method="POST">
        Usuario: <input type="email" placeholder="Correo" name="correo"/><br><br>
        Contraseña: <input type="password" placeholder="Contraseña" name="contra"/><br><br>
        <button id="centrar" onclick="location.href='registro.php'">Continuar</button>
    </form>
    
</body>

</html>


