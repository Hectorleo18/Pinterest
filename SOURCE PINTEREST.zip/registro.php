<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');
$conn = oci_connect("DB_PINTEREST", "oracle", "localhost:1521/XE");
if (!$conn) {
   $m = oci_error();
   echo $m['message'], "\r\n";
   exit;
}
$correo=filter_input(INPUT_POST,"correo",FILTER_VALIDATE_EMAIL);
if(!$correo){
    echo "Datos ingreasados son incorrectos";
?>
<br><button onclick="location.href='index.php'">Regresar al Inicio</button>
<?php 
//$url=$_SERVER['HTTP_REFERER'];
  //  header("LOCATION:$url");
}
$contra=filter_input(INPUT_POST,"contrasena");
if(isset($correo) && !empty($correo)&& isset($contra) && !empty($contra)){
    echo "correo: ".$correo."\r\n";
echo "contraseña: ".$contra."\r\n";
$stid= oci_parse($conn, "INSERT INTO USUARIOS (usuario, contrasena) values('{$correo}', '{$contra}')");
$exe= oci_execute($stid);

if(!$exe){
	
}
else{
	echo "INGRESADO EXE CON EXITO";
}
$commit=oci_commit($conn);
if(!$commit){
	
}
else{
	echo "INGRESADO COMMIT CON EXITO\r\n";
}
$mensaje = "Línea 1\r\nLínea 2\r\nLínea 3";

// Si cualquier línea es más larga de 70 caracteres, se debería usar wordwrap()
$mensaje = wordwrap($mensaje, 70, "\r\n");

// Enviarlo

$email=mail('danielsanczuniga@gmail.com', 'Mi título', $mensaje);
if($email){
    echo "CORREO ENVIADO";
}
}




